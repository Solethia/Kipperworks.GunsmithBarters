export declare class GunsmithBartersConfig
{
    public addAttachmentBarters: boolean;
    public addGunBarters: boolean;
}